#include<iostream>
using namespace std;
int main(){
	for(int i=1;i<=9;i++)
		cout<<i;
	cout<<i<<endl;
	return 0;
}


