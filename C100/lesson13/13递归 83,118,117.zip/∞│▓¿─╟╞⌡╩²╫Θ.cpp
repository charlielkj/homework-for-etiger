#include<iostream>
using namespace std;
typedef long long ll;
ll F[100];
int main(){
	ll n;
	cin>>n;
	F[1]=F[2]=1;
	for(ll i=3;i<=n;i++)
		F[i]=F[i-1]+F[i-2];
	cout<<F[n]<<endl;
	return 0;
}



