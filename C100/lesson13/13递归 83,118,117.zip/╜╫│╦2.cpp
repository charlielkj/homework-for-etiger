#include<iostream>
using namespace std;
typedef long long ll;
ll f(ll x){
	if(x==0) return 1;
	return f(x-1)*x;
}
int main(){
	ll n;
	cin>>n;
	cout<<f(n);
	return 0;
}



