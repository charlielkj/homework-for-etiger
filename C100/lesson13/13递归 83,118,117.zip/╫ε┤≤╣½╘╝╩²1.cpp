#include<iostream>
#include<algorithm> 
using namespace std;
int main(){
	int a,b,i;
	cin>>a>>b;
	for(i=min(a,b);i>=1;i--)
		if(a%i==0&&b%i==0) break;
	cout<<i<<endl;	
	return 0;
} 


