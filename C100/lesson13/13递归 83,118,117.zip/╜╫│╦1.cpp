#include<iostream>
using namespace std;
typedef long long ll;
ll f(ll x){
	ll ans=1;
	for(ll i=2;i<=x;i++)
		ans*=i;
	return ans;
}
int main(){
	ll n;
	cin>>n;
	cout<<f(n);
	return 0;
}



