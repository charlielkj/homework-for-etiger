#include<iostream>
using namespace std;
int gcd(int x,int y){
	int r;
	while(r=x%y){
		x=y;
		y=r;
	}
	return y;
}
int main(){
	int a,b;
	cin>>a>>b;	
	cout<<gcd(a,b)<<endl;	
	return 0;
} 


