#include<iostream>
using namespace std;
void cat(){
	cout<<"m=^o^=m"<<endl; 
	cout<<"(=^ ^=)"<<endl;
}
void happy(){	
	cout<<"q(*^___^*)p"<<endl;
	cout<<"=={*OoO*}=="<<endl;
}
int main(){
	happy();
	cat();
	happy();
	return 0;
}



