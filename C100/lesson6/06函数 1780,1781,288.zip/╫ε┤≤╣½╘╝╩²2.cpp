#include<iostream>
using namespace std;
int main(){
	int a,b,r;
	cin>>a>>b;
	while(r=a%b){
		a=b;
		b=r;
	}
	cout<<b<<endl;	
	return 0;
} 


