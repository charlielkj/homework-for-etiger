#include<bits/stdc++.h>
using namespace std;
int x=1;
int main(){
	cout<<x<<endl;
	int x=2;
	cout<<x<<endl;	
	if(1){
		int x=3;
		cout<<x<<endl;
	}
	cout<<x<<endl;	
	return 0;
} 


