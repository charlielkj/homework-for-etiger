#include<iostream>
using namespace std;
int f[3][2];
int main(){	
	cout<<f[0]<<endl;
	cout<<f[1]<<endl;
	cout<<f[2]<<endl;
	cout<<f<<endl;
	return 0;
} 


