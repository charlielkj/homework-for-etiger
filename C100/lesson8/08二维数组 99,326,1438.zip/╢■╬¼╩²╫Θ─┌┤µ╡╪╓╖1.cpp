#include<iostream>
using namespace std;
int f[3][2];
int main(){	
	cout<<&f[0][0]<<endl;
	cout<<&f[0][1]<<endl;
	cout<<&f[1][0]<<endl;
	cout<<&f[1][1]<<endl;
	cout<<&f[2][0]<<endl;
	cout<<&f[2][1]<<endl;
	return 0;
} 


