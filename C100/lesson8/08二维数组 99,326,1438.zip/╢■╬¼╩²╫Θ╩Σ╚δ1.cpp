#include<iostream>
using namespace std;
int f[3][4];
int main(){
	for(int i=0;i<3;i++)
		for(int j=0;j<4;j++)
			cin>>f[i][j]; 
	for(int i=0;i<3;i++){
		for(int j=0;j<4;j++)
			cout<<f[i][j]<<' ';
		cout<<endl;  
	}
	return 0;
} 


