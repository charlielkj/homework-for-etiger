#include<iostream>
using namespace std;
int main(){
	int f[3];
	cout<<&f[0]<<endl;
	cout<<&f[1]<<endl;
	cout<<&f[2]<<endl;
	cout<<f<<endl;
	cout<<f+1<<endl;
	cout<<f+2<<endl;
	return 0;
}


