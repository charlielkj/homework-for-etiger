#include<iostream>
using namespace std;
int x[4]={5,6,7,8};
int main(){
	int *p;
	p=x+1;
	cout<<p[0]<<endl;
	cout<<p[1]<<endl;
	cout<<p[2]<<endl;
	return 0;
}


