#include<iostream>
#include<string>
using namespace std;
string x[3]={"ha","wa","la"};
int main(){
	cout<<x<<endl;
	cout<<x+1<<endl;
	cout<<x+2<<endl;
	cout<<*x<<endl;
	cout<<*(x+1)<<endl;
	cout<<*(x+2)<<endl;
	cout<<(x+1)[0]<<endl;
	cout<<(x+1)[1]<<endl;
	return 0;
}


