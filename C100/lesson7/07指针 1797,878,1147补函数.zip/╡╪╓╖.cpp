#include<iostream>
using namespace std;
int main(){
	int x,y,z;
	cout<<&x<<endl;
	cout<<&y<<endl;
	cout<<&z<<endl;
	return 0;
}


